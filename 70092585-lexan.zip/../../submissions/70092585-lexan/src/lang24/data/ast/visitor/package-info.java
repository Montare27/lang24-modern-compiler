/**
 * Abstract syntax tree visitor.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package lang24.data.ast.visitor;