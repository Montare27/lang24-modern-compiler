/**
 * All about abstract syntax trees.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package lang24.data.ast;