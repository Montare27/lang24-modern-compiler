package lang24.data.imc.code.stmt;

import lang24.data.imc.code.*;

/**
 * Intermediate code instruction denoting a statement.
 */
public abstract class ImcStmt extends ImcInstr {
}