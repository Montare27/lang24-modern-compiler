package lang24.data.lin;

/**
 * An abstract chunk of linear code.
 */
public class LinChunk {
}