/**
 * Abstract syntax trees representing types.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package lang24.data.ast.tree.type;