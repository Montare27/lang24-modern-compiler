/**
 * Data used by multiple phases.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package lang24.data;