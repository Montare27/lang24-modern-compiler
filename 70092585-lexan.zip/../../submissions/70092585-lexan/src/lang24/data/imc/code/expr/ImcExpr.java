package lang24.data.imc.code.expr;

import lang24.data.imc.code.*;

/**
 * Intermediate code instruction denoting an expression.
 */
public abstract class ImcExpr extends ImcInstr {
}