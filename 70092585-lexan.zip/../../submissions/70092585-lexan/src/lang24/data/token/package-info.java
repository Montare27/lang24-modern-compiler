/**
 * Tokens produced by lexical analysis.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package lang24.data.token;