/**
 * Intermediate code instructions.
 */
package lang24.data.imc.code;