/**
 * Chucks of linear intermediate code.
 */
package lang24.data.lin;
