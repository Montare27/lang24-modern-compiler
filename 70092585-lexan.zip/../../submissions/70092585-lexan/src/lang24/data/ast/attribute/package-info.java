/**
 * Abstract syntax tree attributes.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package lang24.data.ast.attribute;