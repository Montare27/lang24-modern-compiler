/**
 * Visitors for traversing intermediate code trees.
 */
package lang24.data.imc.visitor;