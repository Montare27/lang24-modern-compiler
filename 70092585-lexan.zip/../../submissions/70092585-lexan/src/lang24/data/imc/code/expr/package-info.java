/**
 * Intermediate code instructions denoting expressions.
 */
package lang24.data.imc.code.expr;