/**
 * Intermediate code instructions denoting statements.
 */
package lang24.data.imc.code.stmt;
