package lang24.data.type;

/**
 * A data type with values.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
public abstract class SemValueType extends SemType {

	/** Constructs a new data type with values. */
	public SemValueType() {
	}

}