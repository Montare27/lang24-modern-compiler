/**
 * Infrastructure for generating logs relating of individual compiler phases.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package lang24.common.logger;