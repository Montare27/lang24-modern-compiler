/**
 * Infrastructure for generating reports.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package lang24.common.report;