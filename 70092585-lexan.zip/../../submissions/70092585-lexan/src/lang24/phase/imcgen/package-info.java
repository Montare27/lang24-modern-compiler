/**
 * Intermediate code generation.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package lang24.phase.imcgen;