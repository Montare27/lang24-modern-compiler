/**
 * Lexical analysis.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package lang24.phase.lexan;