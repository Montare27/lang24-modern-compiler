/**
 * Individual compiler phases.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package lang24.phase;