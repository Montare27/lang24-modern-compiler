/**
 * Intermediate code linearization.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package lang24.phase.imclin;