/**
 * The LANG'24 compiler.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package lang24;